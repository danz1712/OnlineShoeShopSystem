package uk.ac.le.co2103.part2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;
import uk.ac.le.co2103.part2.data.AppDatabase;
import uk.ac.le.co2103.part2.entities.Product;

public class ShoppingListActivity extends AppCompatActivity implements ProductAdapter.ProductClickListener {

    private RecyclerView productsRecyclerView;
    private ProductAdapter adapter;
    private AppDatabase database;
    private int listId;
    private static final int UPDATE_PRODUCT_REQUEST_CODE = 1;
    @Override
    public void onProductClick(Product product) {
        // Empty implementation because it's not needed in this activity
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_list);

        database = AppDatabase.getInstance(this);

        productsRecyclerView = findViewById(R.id.products_recycler_view);
        listId = getIntent().getIntExtra("LIST_ID", -1);
        adapter = new ProductAdapter(this, this);
        productsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        productsRecyclerView.setAdapter(adapter);

        FloatingActionButton fabAddProduct = findViewById(R.id.fab_add_product);
        fabAddProduct.setOnClickListener(v -> {
            Intent addIntent = new Intent(ShoppingListActivity.this, AddProductActivity.class);
            addIntent.putExtra("LIST_ID", listId);
            startActivity(addIntent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshList();
    }

    private void refreshList() {
        if (listId != -1) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    List<Product> products = database.productDao().getProductsForShoppingList(listId);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            adapter.setProducts(products);
                        }
                    });
                }
            }).start();
        }
    }

    @Override
    public void onProductLongClick(Product product) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Edit or delete the selected product?")
                .setPositiveButton("Edit", (dialog, which) -> {
                    Intent intent = new Intent(ShoppingListActivity.this, UpdateProductActivity.class);
                    intent.putExtra("PRODUCT_ID", product.getId());
                    startActivityForResult(intent, UPDATE_PRODUCT_REQUEST_CODE);
                })
                .setNegativeButton("Delete", (dialog, which) -> adapter.deleteProduct(product))
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == UPDATE_PRODUCT_REQUEST_CODE && resultCode == RESULT_OK) {
            refreshList();
        }
    }
}

package uk.ac.le.co2103.part2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import uk.ac.le.co2103.part2.data.AppDatabase;
import uk.ac.le.co2103.part2.entities.ShoppingList;

public class CreateListActivity extends AppCompatActivity {

    private EditText editTextName;
    private AppDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_list);

        database = AppDatabase.getInstance(this);

        editTextName = findViewById(R.id.editTextListName);
        Button buttonCreate = findViewById(R.id.buttonCreateList);
        buttonCreate.setOnClickListener(v -> {
            String listName = editTextName.getText().toString().trim();
            if (listName.isEmpty()) {
                Toast.makeText(this, "List name is required", Toast.LENGTH_SHORT).show();
                return;
            }

            insertShoppingList(listName);
        });
    }

    private void insertShoppingList(String listName) {
        // Perform database insertion in a separate thread
        new Thread(() -> {
            // Insert the shopping list into the database
            database.shoppingListDao().insertShoppingList(new ShoppingList(listName));

            // Create an intent with the list name as extra data
            Intent returnIntent = new Intent();
            returnIntent.putExtra("LIST_NAME", listName);

            // Set the result and finish the activity
            setResult(RESULT_OK, returnIntent);
            finish();
        }).start();
    }
}

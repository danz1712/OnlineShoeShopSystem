package uk.ac.le.co2103.part2;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;
import uk.ac.le.co2103.part2.data.AppDatabase;
import uk.ac.le.co2103.part2.entities.Product;
import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHolder> {
    private List<Product> products;
    private AppDatabase database;
    private int listId;
    private Context context;
    private ProductClickListener clickListener; // New interface instance

    // Constructor with ProductClickListener parameter
    public ProductAdapter(Context context, ProductClickListener clickListener) {
        this.context = context;
        this.database = AppDatabase.getInstance(context);
        this.clickListener = clickListener;
    }

    public void setListId(int listId) {
        this.listId = listId;
        if (listId != -1) {
            updateProducts(database.productDao().getProductsForShoppingList(listId));
        }
    }

    public void updateProducts(List<Product> products) {
        this.products = products;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Product product = products.get(position);
        holder.textViewProductName.setText(product.getName());
        holder.textViewProductQuantity.setText(String.valueOf(product.getQuantity()));
        holder.textViewProductUnit.setText(product.getUnit());

        holder.itemView.setOnClickListener(v -> {
            if (clickListener != null) {
                clickListener.onProductClick(product); // Handle product click
            }
        });

        holder.itemView.setOnLongClickListener(v -> {
            if (clickListener != null) {
                clickListener.onProductLongClick(product); // Handle product long click
            }
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return products == null ? 0 : products.size();
    }

    public void setProducts(List<Product> products) {
        this.products = products;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewProductName;
        TextView textViewProductQuantity;
        TextView textViewProductUnit;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewProductName = itemView.findViewById(R.id.text_view_product_name);
            textViewProductQuantity = itemView.findViewById(R.id.text_view_product_quantity);
            textViewProductUnit = itemView.findViewById(R.id.text_view_product_unit);
        }
    }

    // ProductClickListener interface
    public interface ProductClickListener {
        void onProductClick(Product product);
        void onProductLongClick(Product product);
    }

    // Method to handle product editing
    private void editProduct(Product product) {
        Intent intent = new Intent(context, UpdateProductActivity.class);
        intent.putExtra("PRODUCT_ID", product.getId());
        context.startActivity(intent);
    }

    // Method to handle product deletion
    public void deleteProduct(Product product) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("Choose an action for this product:")
                .setPositiveButton("Edit", (dialog, which) -> {
                    // Handle edit option
                    editProduct(product);
                })
                .setNegativeButton("Delete", (dialog, which) -> {
                    // Handle delete option
                    new DeleteProductTask().execute(product);
                })
                .setNeutralButton("Cancel", null)
                .show();
    }

    // AsyncTask to delete product
    private class DeleteProductTask extends AsyncTask<Product, Void, Void> {
        @Override
        protected Void doInBackground(Product... products) {
            database.productDao().deleteProduct(products[0]);
            return null;
        }
    }
}

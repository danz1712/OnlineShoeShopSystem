package uk.ac.le.co2103.part2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;
import uk.ac.le.co2103.part2.data.AppDatabase;
import uk.ac.le.co2103.part2.entities.ShoppingList;

public class MainActivity extends AppCompatActivity implements ShoppingListAdapter.OnItemClickListener, ShoppingListAdapter.OnItemLongClickListener {
    private static final String TAG = "MainActivity";
    private RecyclerView shoppingListsRecyclerView;
    private ShoppingListAdapter adapter;
    private FloatingActionButton fab;
    private ActivityResultLauncher<Intent> createListActivityResultLauncher;
    private AppDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        database = AppDatabase.getInstance(this);

        shoppingListsRecyclerView = findViewById(R.id.shopping_lists_recycler_view);
        adapter = new ShoppingListAdapter(this, this, this); // Pass the activity context and listeners
        shoppingListsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        shoppingListsRecyclerView.setAdapter(adapter);

        fab = findViewById(R.id.fab);
        fab.setOnClickListener(v -> {
            Intent intent = new Intent(this, CreateListActivity.class);
            createListActivityResultLauncher.launch(intent);
        });

        setupActivityResultLauncher();
        Log.d(TAG, "onCreate: Activity created.");
    }

    private void setupActivityResultLauncher() {
        createListActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            String listName = data.getStringExtra("LIST_NAME");
                            insertShoppingList(listName);
                            Log.d(TAG, "Added new list: " + listName);
                        }
                    }
                }
        );
    }

    private void insertShoppingList(String listName) {
        Runnable insertRunnable = new Runnable() {
            @Override
            public void run() {
                // Check if the list already exists
                List<ShoppingList> currentLists = database.shoppingListDao().getAllShoppingListsSync();
                for (ShoppingList shoppingList : currentLists) {
                    if (shoppingList.getListName().equals(listName)) {
                        // List already exists, do not insert again
                        return;
                    }
                }

                // List does not exist, insert it into the database
                database.shoppingListDao().insertShoppingList(new ShoppingList(listName));
                // Notify the adapter of the data change
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        loadShoppingLists(); // Reload the shopping lists from the database
                    }
                });
            }
        };
        Thread insertThread = new Thread(insertRunnable);
        insertThread.start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadShoppingLists();
        Log.d(TAG, "onResume: Refreshed adapter");
    }

    private void loadShoppingLists() {
        new Thread(() -> {
            List<ShoppingList> shoppingLists = database.shoppingListDao().getAllShoppingListsSync();
            runOnUiThread(() -> adapter.setShoppingLists(shoppingLists));
        }).start();
    }

    @Override
    public void onItemClick(ShoppingList shoppingList) {
        // Handle item click here
        // For example, navigate to the ShoppingListActivity
        Intent intent = new Intent(this, ShoppingListActivity.class);
        intent.putExtra("LIST_ID", shoppingList.getListId()); // Use getListId() instead of getId()
        startActivity(intent);
    }

    @Override
    public void onItemLongClick(ShoppingList shoppingList) {
        // Handle long item click here
        // For example, show options to delete the shopping list
        showConfirmationDialog(shoppingList);
    }

    private void showConfirmationDialog(ShoppingList shoppingList) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Shopping List");
        builder.setMessage("Are you sure you want to delete this shopping list?");
        builder.setPositiveButton("Confirm", (dialog, which) -> {
            deleteShoppingList(shoppingList); // Call deleteShoppingList if user confirms
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> {
            // Do nothing if user cancels
        });
        builder.show();
    }

    private void deleteShoppingList(ShoppingList shoppingList) {
        int listId = shoppingList.getListId();
        new Thread(() -> {
            // Delete products associated with the shopping list
            database.productDao().deleteProductsForShoppingList(listId);
            // Delete the shopping list
            database.shoppingListDao().deleteShoppingList(listId);
            // Notify the adapter of the data change
            loadShoppingLists();
        }).start();
    }
}
package uk.ac.le.co2103.part2;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import uk.ac.le.co2103.part2.data.AppDatabase;
import uk.ac.le.co2103.part2.data.ProductDao;
import uk.ac.le.co2103.part2.entities.Product;

public class UpdateProductActivity extends AppCompatActivity {

    private EditText editTextName;
    private EditText editTextQuantity;
    private Spinner spinner;
    private Button minusButton;
    private Button plusButton;
    private Button saveButton;

    private int productId;
    private AppDatabase database;
    private ProductDao productDao;
    private ArrayAdapter<CharSequence> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_product);

        editTextName = findViewById(R.id.editTextName);
        editTextQuantity = findViewById(R.id.editTextQuantity);
        spinner = findViewById(R.id.spinner);
        minusButton = findViewById(R.id.minusButton);
        plusButton = findViewById(R.id.plusButton);
        saveButton = findViewById(R.id.saveButton);

        adapter = ArrayAdapter.createFromResource(this,
                R.array.product_units, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        database = AppDatabase.getInstance(this);
        productDao = database.productDao();

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("PRODUCT_ID")) {
            productId = intent.getIntExtra("PRODUCT_ID", -1);
            new GetProductTask().execute(productId);
        }

        minusButton.setOnClickListener(v -> {
            int quantity = Integer.parseInt(editTextQuantity.getText().toString());
            if (quantity > 0) {
                quantity--;
                editTextQuantity.setText(String.valueOf(quantity));
            }
        });

        plusButton.setOnClickListener(v -> {
            int quantity = Integer.parseInt(editTextQuantity.getText().toString());
            quantity++;
            editTextQuantity.setText(String.valueOf(quantity));
        });

        saveButton.setOnClickListener(v -> {
            String name = editTextName.getText().toString().trim();
            String quantityText = editTextQuantity.getText().toString().trim();
            String unit = spinner.getSelectedItem().toString();

            if (name.isEmpty()) {
                Toast.makeText(this, "Please enter a name", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(quantityText);

            Product updatedProduct = new Product(productId, name, quantity, unit);
            new UpdateProductTask().execute(updatedProduct);
        });
    }

    private class GetProductTask extends AsyncTask<Integer, Void, Product> {
        @Override
        protected Product doInBackground(Integer... ids) {
            return productDao.getProductById(ids[0]);
        }

        @Override
        protected void onPostExecute(Product product) {
            if (product != null) {
                editTextName.setText(product.getName());
                editTextQuantity.setText(String.valueOf(product.getQuantity()));
                int spinnerPosition = adapter.getPosition(product.getUnit());
                spinner.setSelection(spinnerPosition);
            } else {
                Toast.makeText(UpdateProductActivity.this, "Product not found", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    private class UpdateProductTask extends AsyncTask<Product, Void, Void> {
        @Override
        protected Void doInBackground(Product... products) {
            productDao.updateProduct(products[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Toast.makeText(UpdateProductActivity.this, "Product updated", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK); // Set result to indicate successful update
            finish();
        }
    }
}

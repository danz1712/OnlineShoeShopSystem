
package uk.ac.le.co2103.part2.data;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;
import uk.ac.le.co2103.part2.entities.Product;

@Dao
public interface ProductDao {


    @Query("SELECT * FROM products WHERE list_id = :listId")
    List<Product> getProductsForShoppingList(int listId);

    @Query("SELECT * FROM products WHERE product_id = :productId")
    Product getProductById(int productId);

    @Query("DELETE FROM products WHERE list_id = :listId")
    void deleteProductsForShoppingList(int listId); // New method to delete products for a shopping list

    @Insert
    void insertProduct(Product product);

    @Delete
    void deleteProduct(Product product);

    @Update
    void updateProduct(Product product);
}

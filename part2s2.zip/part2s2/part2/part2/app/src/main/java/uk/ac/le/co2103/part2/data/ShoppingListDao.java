
package uk.ac.le.co2103.part2.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;
import uk.ac.le.co2103.part2.entities.ShoppingList;

@Dao
public interface ShoppingListDao {
    @Query("SELECT * FROM shopping_lists")
    LiveData<List<ShoppingList>> getAllShoppingLists();

    @Query("SELECT * FROM shopping_lists")
    List<ShoppingList> getAllShoppingListsSync();

    @Query("DELETE FROM shopping_lists WHERE list_id = :listId")
    void deleteShoppingList(int listId); // New method to delete a shopping list

    @Query("DELETE FROM shopping_lists")
    void deleteAll();

    @Insert
    void insertShoppingList(ShoppingList shoppingList);
}

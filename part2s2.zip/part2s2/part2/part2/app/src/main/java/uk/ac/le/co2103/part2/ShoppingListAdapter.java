// ShoppingListAdapter.java
package uk.ac.le.co2103.part2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import uk.ac.le.co2103.part2.entities.ShoppingList;

public class ShoppingListAdapter extends RecyclerView.Adapter<ShoppingListAdapter.ViewHolder> {

    private List<ShoppingList> shoppingLists;
    private final LayoutInflater inflater;
    private final OnItemClickListener clickListener;
    private final OnItemLongClickListener longClickListener;

    public interface OnItemClickListener {
        void onItemClick(ShoppingList shoppingList);
    }

    public interface OnItemLongClickListener {
        void onItemLongClick(ShoppingList shoppingList);
    }

    public ShoppingListAdapter(Context context, OnItemClickListener clickListener, OnItemLongClickListener longClickListener) {
        this.inflater = LayoutInflater.from(context);
        this.clickListener = clickListener;
        this.longClickListener = longClickListener;
    }

    public void setShoppingLists(List<ShoppingList> shoppingLists) {
        this.shoppingLists = shoppingLists;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.shopping_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ShoppingList currentList = shoppingLists.get(position);
        holder.bind(currentList, clickListener, longClickListener);
    }

    @Override
    public int getItemCount() {
        return shoppingLists == null ? 0 : shoppingLists.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView textViewListName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewListName = itemView.findViewById(R.id.textViewName);
        }

        public void bind(final ShoppingList shoppingList, final OnItemClickListener clickListener, final OnItemLongClickListener longClickListener) {
            textViewListName.setText(shoppingList.getListName());
            itemView.setOnClickListener(v -> clickListener.onItemClick(shoppingList));
            itemView.setOnLongClickListener(v -> {
                longClickListener.onItemLongClick(shoppingList);
                return true;
            });
        }
    }
}

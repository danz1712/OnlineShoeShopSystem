package uk.ac.le.co2103.part2.data;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import uk.ac.le.co2103.part2.entities.Product;
import uk.ac.le.co2103.part2.entities.ShoppingList;

// Define the Room database class with annotations
@Database(entities = {Product.class, ShoppingList.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    // Define abstract methods to access DAOs
    public abstract ProductDao productDao();
    public abstract ShoppingListDao shoppingListDao();

    // Define static variables and executor service for database operations
    private static volatile AppDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    public static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    // Singleton pattern: Get an instance of the database
    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    // Build the database instance
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "shopping_list_database")
                            .addCallback(sRoomDatabaseCallback) // Add callback for database creation
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    // Define a callback for database creation
    private static RoomDatabase.Callback sRoomDatabaseCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(SupportSQLiteDatabase db) {
            super.onCreate(db);
            // Execute database operations asynchronously in a background thread
            databaseWriteExecutor.execute(() -> {
                // Perform any initial database population here if needed
            });
        }
    };

    // Method to delete all shopping lists
    public void deleteAllShoppingLists() {
        // Execute deletion operation asynchronously in a background thread
        databaseWriteExecutor.execute(() -> {
            shoppingListDao().deleteAll();
        });
    }
}

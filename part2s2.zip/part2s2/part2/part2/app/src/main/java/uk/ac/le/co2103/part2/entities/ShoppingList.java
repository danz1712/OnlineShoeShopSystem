package uk.ac.le.co2103.part2.entities;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "shopping_lists")
public class ShoppingList {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "list_id")
    private int listId;

    @ColumnInfo(name = "list_name")
    private String listName;

    // Constructor
    public ShoppingList(String listName) {
        this.listName = listName;
    }

    // Getter for listId
    public int getListId() {
        return listId;
    }

    // Setter for listId
    public void setListId(int listId) {
        this.listId = listId;
    }

    // Getter for listName
    public String getListName() {
        return listName;
    }

    // Setter for listName
    public void setListName(String listName) {
        this.listName = listName;
    }

    // Getter for id (auto-generated)
    public int getId() {
        return listId;
    }
}

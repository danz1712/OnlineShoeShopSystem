package uk.ac.le.co2103.part2;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

import uk.ac.le.co2103.part2.data.AppDatabase;
import uk.ac.le.co2103.part2.data.ProductDao;
import uk.ac.le.co2103.part2.entities.Product;

public class AddProductActivity extends AppCompatActivity {

    private EditText editTextName;
    private EditText editTextQuantity;
    private Spinner spinner;
    private Button addButton;
    private ProductDao productDao;
    private int listId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        productDao = AppDatabase.getInstance(this).productDao();

        editTextName = findViewById(R.id.editTextName);
        editTextQuantity = findViewById(R.id.editTextQuantity);
        spinner = findViewById(R.id.spinner);
        addButton = findViewById(R.id.addButton);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.product_units, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        listId = getIntent().getIntExtra("LIST_ID", -1);

        addButton.setOnClickListener(v -> {
            String name = editTextName.getText().toString().trim();
            String quantityText = editTextQuantity.getText().toString().trim();
            String unit = spinner.getSelectedItem().toString();

            if (name.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(quantityText);

            Product newProduct = new Product(listId, name, quantity, unit);
            new InsertProductTask().execute(newProduct);
        });
    }

    private class InsertProductTask extends AsyncTask<Product, Void, Void> {
        @Override
        protected Void doInBackground(Product... products) {
            productDao.insertProduct(products[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Toast.makeText(AddProductActivity.this, "Product added", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}

document.addEventListener("DOMContentLoaded", function() {
        const urlParams = new URLSearchParams(window.location.search);
        const reviewId = urlParams.get('reviewId');
        const reviewsContainer = document.getElementById('review-details');
    
        const reviews = {
            "1": {
                name: "Hamilton",
                imageUrl: "images/hamilton.jpg",
                description: "The story of America's Founding Father Alexander Hamilton, featuring a score that blends hip-hop, jazz, blues, rap, R&B, and Broadway.",
                rating: 5,
                userReviews: ["Revolutionary in every sense of the word.", "Perhaps the most important musical of the decade."],
                ticketUrl: "https://www.london-theater-tickets.com/hamilton-tickets/"
            },
            "2": {
                name: "Les Misérables",
                imageUrl: "images/lesmiserables.jpg",
                description: "Experience the emotional depths of revolutionary France.",
                rating: 5,
                userReviews: ["Absolutely breathtaking!", "A must-see for any musical enthusiast."],
                ticketUrl: "https://www.london-theater-tickets.com/les-miserables-tickets/"
            },
            "3": {
                name: "The Phantom of the Opera",
                imageUrl: "images/phantomopera.jpg",
                description: "A haunting story of love and intrigue.",
                rating: 4,
                userReviews: ["Captivating from start to finish.", "The music is unforgettable!"],
                ticketUrl: "https://www.london-theater-tickets.com/the-phantom-of-the-opera-tickets/"
            },
            "4": {
                name: "The Lion King",
                imageUrl: "images/lionking.jpg",
                description: "Follow Simba's journey from a young cub to the king of the jungle in this spectacular musical.",
                rating: 5,
                userReviews: ["A breathtaking spectacle, rich in color and emotion.", "A masterpiece of artistic creativity."],
                ticketUrl: "https://www.london-theater-tickets.com/the-lion-king-tickets/"
            },
            "5": {
                name: "Mamma Mia",
                imageUrl: "images/mammamia.jpg",
                description: "Join the ultimate feel-good party as Mamma Mia combines ABBA's greatest hits with an enchanting tale of love, laughter, and friendship.",
                rating: 3,
                userReviews: ["An irresistibly charming musical that's also a trip down memory lane.", "Joyous and uplifting - you'll leave with a smile on your face!"],
                ticketUrl: "https://www.london-theater-tickets.com/mamma-mia-tickets/"
            }
        };

        const review = reviews[reviewId];
        if (review) {
            reviewsContainer.innerHTML = `
                <h2>${review.name}</h2>
                <img src="${review.imageUrl}" alt="${review.name}" class="central-image">
                <p>${review.description}</p>
                <div class="star-rating">Rating: ${'<span class="gold-star">★</span>'.repeat(review.rating)}</div>
                <h3>User Reviews</h3>
                <ul id="user-reviews-list"></ul>
            `;
            const buyTicketsLink = document.getElementById('buy-tickets');
            buyTicketsLink.href = review.ticketUrl;

            // Load and display user reviews
            const userReviews = JSON.parse(localStorage.getItem('userReviews') || '{}')[reviewId] || [];
            const userReviewsList = document.getElementById('user-reviews-list');
            userReviews.forEach(({ rating, reviewText }) => {
                const reviewItem = document.createElement('li');
                reviewItem.textContent = `${rating} stars - ${reviewText}`;
                userReviewsList.appendChild(reviewItem);
            });
        } else {
            reviewsContainer.innerHTML = '<p>Review not found.</p>';
        }
    });
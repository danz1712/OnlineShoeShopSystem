 document.addEventListener('DOMContentLoaded', function() {
    const topShows = [
        { id: 1, name: "Hamilton", description: "The story of America's Founding Father Alexander Hamilton, featuring a score that blends hip-hop, jazz, blues, rap, R&B, and Broadway.", imageUrl: "images/hamilton.jpg", url: "reviews-details.html?reviewId=1" },
        { id: 2, name: "Les Misérables", description: "A captivating story of love and revolution in France.", imageUrl: "images/lesmiserables.jpg", url: "reviews-details.html?reviewId=2" },
        { id: 3,name: "The Phantom of the Opera", description: "A dramatic tale set in a mysterious opera house.", imageUrl: "images/phantomopera.jpg", url: "reviews-details.html?reviewId=3" }
    ];

    const showsList = document.getElementById('shows-list');
    topShows.forEach(show => {
        const showItem = document.createElement('li');
        showItem.className = 'show-item';

        const showDetails = document.createElement('div');
        showDetails.className = 'show-details';

        const showTitle = document.createElement('h3');
        showTitle.textContent = show.name;

        const showImage = document.createElement('img');
        showImage.className = 'show-image';
        showImage.src = show.imageUrl;
        showImage.alt = show.name;

        const showDescription = document.createElement('p');
        showDescription.className = 'show-description';
        showDescription.textContent = show.description;

        showDetails.appendChild(showTitle);
        showDetails.appendChild(showImage);
        showDetails.appendChild(showDescription);

        showItem.appendChild(showDetails);

        showItem.addEventListener('click', () => {
            window.location.href = `review-details.html?reviewId=${show.id}`;
        });

        showsList.appendChild(showItem);
    });

            // Set active link in navigation
            var path = window.location.pathname;
            var page = path.split("/").pop();
            var navLinks = document.querySelectorAll('nav a');
            navLinks.forEach(function(link) {
                if (link.href.includes(page)) {
                    link.classList.add('active');
                }
            });
        });
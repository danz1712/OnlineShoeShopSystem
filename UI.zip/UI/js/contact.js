document.addEventListener("DOMContentLoaded", function() {
        // Get the current URL
        var path = window.location.pathname;
        // Extract the filename
        var page = path.split("/").pop();
    
        // Check if there is a corresponding navbar item and set it as active
        var navLinks = document.querySelectorAll('nav a');
        navLinks.forEach(function(link) {
            if (link.href.includes(page)) {
                link.classList.add('active');
            }
        });
    });
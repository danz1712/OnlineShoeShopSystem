document.addEventListener("DOMContentLoaded", function() {
    var path = window.location.pathname;
    var page = path.split("/").pop();
    document.querySelectorAll('nav a').forEach(function(link) {
        if (link.href.includes(page)) {
            link.classList.add('active');
        }
    });

    const shows = [
        { name: "Les Misérables", occasion: "anniversary", mood: "serious", image: "images/lesmiserables.jpg", reviewPage: "review-details.html?reviewId=2" },
        { name: "The Phantom of the Opera", occasion: "first_date", mood: "serious", image: "images/phantomopera.jpg", reviewPage: "review-details.html?reviewId=3" },
        { name: "Mamma Mia", occasion: "birthday", mood: "light-hearted", image: "images/mammamia.jpg", reviewPage: "review-details.html?reviewId=5" },
        { name: "The Lion King", occasion: "family", mood: "light-hearted", image: "images/lionking.jpg", reviewPage: "review-details.html?reviewId=4" },
        { name: "Hamilton", occasion: "family", mood: "light-hearted", image: "images/hamilton.jpg", reviewPage: "review-details.html?reviewId=1" }
    ];

    window.recommendShows = function() {
        var selectedOccasion = document.getElementById('occasion').value;
        var selectedMood = document.getElementById('mood').value;
        var results = shows.filter(show => show.occasion === selectedOccasion && show.mood === selectedMood);
        
        var showList = document.getElementById('showList');
        showList.innerHTML = '';

        results.forEach(function(show) {
            var li = document.createElement('li');
            li.innerHTML = `<a href="${show.reviewPage}"><img src="${show.image}" alt="${show.name}" style="height:100px;"> ${show.name}</a>`;
            showList.appendChild(li);
        });

        if (results.length === 0) {
            showList.innerHTML = '<li>No shows match your criteria.</li>';
        }
    };
});
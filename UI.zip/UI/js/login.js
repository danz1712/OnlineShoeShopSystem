     document.addEventListener("DOMContentLoaded", function() {
    // Get the current URL
    var path = window.location.pathname;
    // Extract the filename
    var page = path.split("/").pop();

    // Check if there is a corresponding navbar item and set it as active
    var navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(function(link) {
        if (link.href.includes(page)) {
            link.classList.add('active');
        }
    });
});

    function handleLogin() {
        // Get user input values (you would normally validate these and send to server)
        var email = document.getElementById('email').value;
        var password = document.getElementById('password').value;
    
        // Simulate a login check (this is purely for demonstration; replace with actual server-side logic)
        if (email !== '' && password !== '') {
            // Redirect to the home page on successful "login"
            window.location.href = 'home.html';
        } else {
            // Optionally, handle error (show an error message)
            alert('Please enter both email and password.');
        }
    }
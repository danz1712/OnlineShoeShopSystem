
        document.addEventListener("DOMContentLoaded", function() {
            var path = window.location.pathname;
        var page = path.split("/").pop();
        var navLinks = document.querySelectorAll('nav a');
        navLinks.forEach(function(link) {
            if (link.href.includes(page)) {
                link.classList.add('active');
            }
        });
            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                events: [
                    { title: 'Hamilton', date: '2024-05-25', url: 'details.html?show=hamilton' },
                    { title: 'Les Misérables', date: '2024-06-01', url: 'details.html?show=les-miserables' },
                    { title: 'The Phantom of the Opera', date: '2024-06-15', url: 'details.html?show=phantom-opera' },
                    { title: 'The Lion King', date: '2024-06-20', url: 'details.html?show=lion-king' },
                    { title: 'Mamma Mia', date: '2024-06-25', url: 'details.html?show=mamma-mia' }
                ],
                eventClick: function(info) {
                    info.jsEvent.preventDefault(); 
                    window.location.href = info.event.url; 
                }
            });
            calendar.render();
        });
 
 document.addEventListener("DOMContentLoaded", function() {
        var path = window.location.pathname;
        var page = path.split("/").pop();
        var navLinks = document.querySelectorAll('nav a');
        navLinks.forEach(function(link) {
            if (link.href.includes(page)) {
                link.classList.add('active');
            }
        });
    
        const reviews = [
            { id: 1, name: "Hamilton", rating: 5, description: "The story of America's Founding Father Alexander Hamilton, featuring a score that blends hip-hop, jazz, blues, rap, R&B, and Broadway." },
            { id: 2, name: "Les Misérables", rating: 5, description: "A captivating story of love and revolution in France." },
            { id: 3, name: "The Phantom of the Opera", rating: 4, description: "A dramatic tale set in a mysterious opera house." },
            { id: 4, name: "The Lion King", rating: 5, description: "A vibrant and exciting tale of Simba, the young lion prince, as he journeys through the Circle of Life." },
            { id: 5, name: "Mamma Mia", rating: 3, description: "The story-telling magic of ABBA's timeless songs propels this enchanting tale of love, laughter and friendship." }
        ];
    
        const reviewsList = document.getElementById('reviews-list');
        reviews.forEach(review => {
            const reviewItem = document.createElement('div');
            reviewItem.className = 'review-item';
            reviewItem.innerHTML = `
                <h3>${review.name}</h3>
                <div class="star-rating">${'★'.repeat(review.rating)}</div>
                <p>${review.description}</p>`;
            reviewItem.addEventListener('click', () => {
                window.location.href = `review-details.html?reviewId=${review.id}`;
            });
            reviewsList.appendChild(reviewItem);
        });
    
        const musicalSelect = document.getElementById('musical-select');
        reviews.forEach(function(review) {
            const option = document.createElement('option');
            option.value = review.id;
            option.textContent = review.name;
            musicalSelect.appendChild(option);
        });
    
        document.getElementById('submit-review').addEventListener('submit', function(event) {
            event.preventDefault();
            const reviewId = musicalSelect.value;
            const rating = document.getElementById('star-rating').value;
            const reviewText = document.getElementById('user-review').value;
    
            let userReviews = JSON.parse(localStorage.getItem('userReviews') || '{}');
            if (!userReviews[reviewId]) {
                userReviews[reviewId] = [];
            }
            userReviews[reviewId].push({ rating, reviewText });
            localStorage.setItem('userReviews', JSON.stringify(userReviews));
    
            alert('Review submitted successfully!');
            document.getElementById('user-review').value = ''; // Clear the form
        });
    });
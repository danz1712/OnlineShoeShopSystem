  document.addEventListener("DOMContentLoaded", function() {
    // Get the current URL
    var path = window.location.pathname;
    // Extract the filename
    var page = path.split("/").pop();

    // Check if there is a corresponding navbar item and set it as active
    var navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(function(link) {
        if (link.href.includes(page)) {
            link.classList.add('active');
        }
    });
});

    function handleRegistration() {
        // Validate the form inputs (simple validation here, just for demonstration)
        var name = document.getElementById('name').value;
        var email = document.getElementById('email').value;
        var password = document.getElementById('password').value;
        var confirmPassword = document.getElementById('confirm_password').value;
    
        if (email && password && name && password === confirmPassword) {
            // Display the success message
            document.getElementById('message').innerText = 'Account successfully created! Redirecting to login...';
    
            // Redirect to login page after 2 seconds
            setTimeout(function() {
                window.location.href = 'login.html';
            }, 2000); // 2000 milliseconds = 2 seconds
        } else {
            // Display an error message if the validation fails
            document.getElementById('message').innerText = 'Please make sure all fields are filled and passwords match.';
        }
    }